using System;

public enum AccountType	{Checking, Deposit}

// TODO: Declare a Struct


class Test
{
    static void Main()
    {
		// TODO: Test Structure
    }
}


