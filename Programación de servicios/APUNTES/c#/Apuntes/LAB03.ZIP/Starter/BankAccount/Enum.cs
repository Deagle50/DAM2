using System; // System namespace. 

// TODO: Declare enum

class TestAccount
{
    static void Main()
    {
	// TODO: Write Code
    }
}

