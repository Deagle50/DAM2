namespace Utils
{
    using System;

    /// <summary>
    ///   This the test harness
    /// </summary>

    public class Test
    {
        public static void Main() 
        {
			int num = 65;
			string msg = "A String";
			Coordinate c = new Coordinate(21.0,68.0);

			Utils.Display(num);
			Utils.Display(msg);
			Utils.Display(c);
        }
    }
}
