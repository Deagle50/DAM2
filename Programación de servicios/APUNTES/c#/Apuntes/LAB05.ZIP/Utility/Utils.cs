namespace Utils
{
    using System;

    public class Utils
    {
        // Write your methods in here
    }
}
