
using System;

class MatrixMultiply {
    static void Main() {
        // ...
    }
}
    
