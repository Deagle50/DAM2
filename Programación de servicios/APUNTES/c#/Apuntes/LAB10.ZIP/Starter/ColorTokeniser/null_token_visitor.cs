
namespace CSharp
{
    public class NullTokenVisitor : ITokenVisitor
    {
        
    }
}
